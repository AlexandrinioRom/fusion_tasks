//Task number 1



// function elevate(x, n) {
//     if(n==1) {
//         return x
//     }
//     else {
//         return x * elevate(x,n-1)
//     }
// }



// const elevate = (x, n) => (n==1) ? x : x * elevate(x, n-1)

// console.log(elevate(3,3))

