//Task number 3



let num = 120113;

function showText(num) {
    
    const arrOfNum = String(num).split('').reverse(); 
    const arrOfNumLength = arrOfNum.length;
    let category;

    if(arrOfNumLength > 3) {

        if(+arrOfNum[3] == 1){
            category = 'тысяча';
        }
        if(+arrOfNum[3] == 2 || +arrOfNum[3] == 3 || +arrOfNum[3] == 4) {
            category = 'тысячи';
        }
        if(+arrOfNum[3] > 4 || +arrOfNum[3] == 0) {
            category = 'тысяч';
        }
    }


    for (let i = 0; i < arrOfNumLength; i++) {
        arrOfNum[i] = bitnessOfNumber(arrOfNum[i],i)
    }

    if (arrOfNumLength > 3) {

        if (arrOfNum[3] != '') {
            arrOfNum.splice(3,0, category);
        } else arrOfNum.splice(3, 0, 'тысяч');

    }

    returnBitnes(arrOfNum);

    function bitnessOfNumber (element, index) {

        if (index == 3 || index == 0) {

            if (element == 0) {return ''}
            if (element == 1) {return 'один'}
            if (element == 2) {return 'два'}
            if (element == 3) {return 'три' } 
            if (element == 4) {return 'четыре'}
            if (element == 5) {return 'пять'}
            if (element == 6) {return 'шесть'}
            if (element == 7) {return 'семь'}
            if (element == 8) {return 'восемь'}
            if (element == 9) {return 'девять'}

        }  

        if (index == 4 || index == 1) {

            if (element == 0) {return ''}
            if (element == 1) {return 'десять'}
            if (element == 2) {return 'двадцать'}
            if (element == 3) {return 'тридцать' } 
            if (element == 4) {return 'сорок'}
            if (element == 5) {return 'пятьдесят'}
            if (element == 6) {return 'шестьдесят'}
            if (element == 7) {return 'семьдесят'}
            if (element == 8) {return 'восемьдесят'}
            if (element == 9) {return 'девяносто'}

        }

        if (index == 5 || index == 2) {

            if (element == 0) {return ''}
            if (element == 1) {return 'сто'}
            if (element == 2) {return 'двести'}
            if (element == 3) {return 'тристо'}
            if (element == 4) {return 'четыресто'}
            if (element == 5) {return 'пятьсот'}
            if (element == 6) {return 'шестьсот'}
            if (element == 7) {return 'семьсот'}
            if (element == 8) {return 'восемьсот'}
            if (element == 9) {return 'девятьсот'}
        }
    }

    function returnBitnes(arrOfNum) {

        if (arrOfNum[1]=='десять' && arrOfNum[0]=='один') {
            arrOfNum.splice(0,2,'','одинадцать')
        } 
        if (arrOfNum[1]=='десять' && arrOfNum[0]=='два') {
            arrOfNum.splice(0,2,'','двенадцать')
        }
        if (arrOfNum[1]=='десять' && arrOfNum[0]=='три') {
            arrOfNum.splice(0,2,'','тринадцать')
        }
        if (arrOfNum[1]=='десять' && arrOfNum[0]=='четыре') {
            arrOfNum.splice(0,2,'','четырнадцать')
        }
        if (arrOfNum[1]=='десять' && arrOfNum[0]=='пять') {
            arrOfNum.splice(0,2,'','пятнадцать')
        }
        if (arrOfNum[1]=='десять' && arrOfNum[0]=='шесть') {
            arrOfNum.splice(0,2,'','шестнадцать')
        }
        if (arrOfNum[1]=='десять' && arrOfNum[0]=='семь') {
            arrOfNum.splice(0,2,'','семнадцать')
        }
        if (arrOfNum[1]=='десять' && arrOfNum[0]=='восемь') {
            arrOfNum.splice(0,2,'','восемнадцать')
        }
        if (arrOfNum[1]=='десять' && arrOfNum[0]=='девять') {
            arrOfNum.splice(0,2,'','девятнадцать');
        }

        ////////////////////////////////////////////////////

        if (arrOfNum[4]=='десять' && arrOfNum[3]=='один') {
            arrOfNum.splice(3,2,'','одинадцать')
        } 
        if (arrOfNum[4]=='десять' && arrOfNum[3]=='два') {
            arrOfNum.splice(3,2,'','двенадцать')
        }
        if (arrOfNum[4]=='десять' && arrOfNum[3]=='три') {
            arrOfNum.splice(3,2,'','тринадцать')
        }
        if (arrOfNum[4]=='десять' && arrOfNum[3]=='четыре') {
            arrOfNum.splice(3,2,'','четырнадцать')
        }
        if (arrOfNum[4]=='десять' && arrOfNum[3]=='пять') {
            arrOfNum.splice(3,2,'','пятнадцать')
        }
        if (arrOfNum[4]=='десять' && arrOfNum[3]=='шесть') {
            arrOfNum.splice(3,2,'','шестнадцать')
        }
        if (arrOfNum[4]=='десять' && arrOfNum[3]=='семь') {
            arrOfNum.splice(3,2,'','семнадцать')
        }
        if (arrOfNum[4]=='десять' && arrOfNum[3]=='восемь') {
            arrOfNum.splice(3,2,'','восемнадцать')
        }
        if (arrOfNum[4]=='десять' && arrOfNum[3]=='девять') {
            arrOfNum.splice(3,2,'','девятнадцать');
        }

        return  arrOfNum;
        
    }

    num = arrOfNum.reverse().join(' ');
    return num;
}
console.log(showText(num));