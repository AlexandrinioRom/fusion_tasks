//Task number 2 

// const openArray = arr => arr.join(',').split(',').map(Number);

// const arr = [1,2,[3,4,[5,6,],7,[9,[8]]]];

// console.log(openArray(arr));